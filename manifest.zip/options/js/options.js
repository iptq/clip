var Clippr = Clippr || {};
Clippr.Options = Clippr.Options || {};

window.name = "clippr";
var oauth;

$(function () {
	$('[data-toggle="tooltip"]').tooltip();

	chrome.storage.local.get("clippr", function(res) {
		Clippr.Options = res;
	});

	if (Clippr.Options.Type) {
		if (Clippr.Options.Type == "bitly") {
			$("#service_bitly").prop("checked", true);
		}
	}

	$(".radio input[type=radio]").change(function() {
		var selected = $(this).val();
		if (selected == "none") {
			// what do i do here
		} else if (selected == "bitly") {
			oauth = window.open("redirect.html",
				"oauth",
				"menubar=no");
			oauth.callback = function(result) {
				console.log(result);
			};
		}
	});
});